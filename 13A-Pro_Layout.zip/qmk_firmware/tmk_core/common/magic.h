#ifndef MAGIC_H
#define MAGIC_H

void magic(void);

#endif
